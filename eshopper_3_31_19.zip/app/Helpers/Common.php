<?php
/**
 * Created by PhpStorm.
 * User: Abdullah
 * Date: 11/05/2018
 * Time: 7:46 PM
 */

use App\Brand;
use App\Category;
use App\product;
use App\Slider;


/**
 * Current controller name
 * @return string
 */
function currentController(){
    return class_basename(Route::current()->controller);
}

/**
 * Current route
 * @return string
 */
function currentRoute(){
    return Route::current()->uri();
}

/**
 * Current route name
 * @return string|null
 */
function currentRouteName(){
   return Route::currentRouteName();
}

/**
 * Count product for frontend
 * @param $whiceId
 * @param $id
 * @return int
 */
function countProduct($whiceId, $id){
    $products = product::with('brand', 'category')
        ->where(['status' => 1, $whiceId => $id])
        ->get();
    return $products->count();
}

/**
 * Get all published slider for fronted
 * @return mixed
 */
function sliders(){
    $sliders = Slider::orderBy('id', 'desc')->where('status', true)->get();
    return $sliders;
}

/**
 * Get all published category for frontend
 * @return mixed
 */
function categories(){
    $categories = Category::orderBy('id', 'desc')->where('status', true)->get();
    return $categories;
}

/**
 * Get all published brand for frontend
 * @return mixed
 */
function brands(){
    $brands = Brand::orderBy('id', 'desc')->where('status', true)->get();
    return $brands;
}
