<?php

use Faker\Generator as Faker;

$factory->define(App\test::class, function (Faker $faker) {
    return [
        //
    ];
});
